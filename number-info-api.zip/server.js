const express = require("express");
const axios = require("axios");
require("dotenv").config();

const app = express();
const PORT = 3000;

const API_KEY = process.env.API_KEY;

app.get("/number-info", async (req, res) => {
  const number = req.query.number;

  if (!number) {
    return res.json({ error: "Number is required" });
  }

  try {
    const response = await axios.get(
      `http://apilayer.net/api/validate?access_key=${API_KEY}&number=${number}`
    );

    res.json(response.data);
  } catch (error) {
    res.json({ error: "API request failed" });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
